package org.okou.mybatis.annotation.model;


import org.okou.lippen.dao.annotation.IMapperEntity;
import org.okou.lippen.dao.annotation.generic.impl.AbstractMapperEntity;
import org.okou.lippen.dao.annotation.mybatis.annotation.Id;
import org.okou.lippen.dao.annotation.mybatis.annotation.Table;
@Table("user")
public class User extends AbstractMapperEntity implements IMapperEntity{
	@Id
	private Integer id;
	private String userName;
	private Integer userAge;
	private String userAddress;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	
	public String toString()
	{
		return "{id:" + id 
		+ ",userName:" + userName
		+ ",userAge:" + userAge
		+ ",userAddress:" + userAddress
		+ "}";
	}
}