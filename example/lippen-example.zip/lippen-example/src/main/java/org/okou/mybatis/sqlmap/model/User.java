package org.okou.mybatis.sqlmap.model;

import org.okou.lippen.dao.sqlmap.ISqlMapEntity;

public class User implements ISqlMapEntity{
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String userName;
	private Integer userAge;
	private String userAddress;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	
	public String toString()
	{
		return "{id:" + id 
		+ ",userName:" + userName
		+ ",userAge:" + userAge
		+ ",userAddress:" + userAddress
		+ "}";
	}
	
	@Override
	public String selectId()
	{
		return "user.select";//ibatis 的statement id
	}
	@Override
	public String insertId()
	{
		return "user.insert";
	}
	@Override
	public String updateId()
	{
		return "user.update";
	}
	@Override
	public String deleteId()
	{
		return "user.delete";
	}
}
