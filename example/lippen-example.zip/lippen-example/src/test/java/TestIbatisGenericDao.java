import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.okou.ibatis.model.User;
import org.okou.lippen.dao.IGenericDao;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:ibatis-sqlmap-property.xml", "classpath:lippen-ibatis.xml", "classpath:ibatis-test.xml"})
public class TestIbatisGenericDao
{
	@Resource
	IGenericDao<User> ibatisGenericSqlMapDao;
	
	@Test
	public void test()
	{
		User u = new User();
		u.setId(12);
		System.out.println(ibatisGenericSqlMapDao.get(u));
	}
}
