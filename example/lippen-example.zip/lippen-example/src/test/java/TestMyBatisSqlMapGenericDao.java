import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.okou.lippen.dao.IGenericDao;
import org.okou.mybatis.sqlmap.model.User;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:mybatis-sqlmap-property.xml", "classpath:lippen-mybatis.xml", "classpath:mybatis-test.xml"})
public class TestMyBatisSqlMapGenericDao
{
	@Resource
	IGenericDao<User> mybatisGenericSqlMapDao;
	
	@Test
	public void test()
	{
		User u = new User();
		u.setId(12);
		System.out.println(mybatisGenericSqlMapDao.get(u));
	}
}
